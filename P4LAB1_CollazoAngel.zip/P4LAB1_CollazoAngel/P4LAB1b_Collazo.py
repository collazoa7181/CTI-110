#Angel Collazo
#November 1,2025
#P4LAB1b
#Program to draw my initials using turtle graphics

#IMPORT THE LIBRARY

import turtle

#Create the turtle window and drawing my initials
win = turtle.Screen()
pen = turtle.Turtle()



#Set turtle options
pen.pensize(5)
pen.pencolor("purple")
pen.shape("arrow")


#First initial
pen.left(75)
pen.forward(100)
pen.right(150)
pen.forward(100)
pen.backward(50)
pen.right(100)
pen.forward(25)


#Pen up to the next position
pen.penup()
pen.backward(100)
pen.pendown()

#Second initial
pen.right(95)
pen.forward(45)
pen.right(90)
pen.forward(50)
pen.backward(50)
pen.right(90)
pen.forward(100)
pen.left(90)
pen.forward(50)

# Finish

win.mainloop()

